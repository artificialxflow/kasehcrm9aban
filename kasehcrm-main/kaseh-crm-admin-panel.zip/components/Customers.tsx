
import React from 'react';
import { CUSTOMERS_DATA } from '../constants';

const Customers: React.FC = () => {
  return (
    <div className="p-6 max-w-7xl mx-auto space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-black text-slate-800">بانک مشتریان 👥</h2>
          <p className="text-slate-500 font-bold mt-1">مدیریت مشتریان وفادار و باشگاه مشتریان کاسه</p>
        </div>
        <button className="bg-slate-900 text-white px-6 py-3 rounded-2xl font-black text-sm hover:bg-slate-800 transition-all flex items-center gap-2">
          <i className="fa-solid fa-file-export"></i>
          خروجی اکسل
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {CUSTOMERS_DATA.map((customer) => (
          <div key={customer.id} className="bg-white rounded-[2.5rem] p-6 border-2 border-slate-100 shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all relative overflow-hidden group">
            <div className={`absolute top-0 left-0 w-2 h-full ${customer.loyaltyLevel === 'طلایی' ? 'bg-amber-400' : customer.loyaltyLevel === 'نقره‌ای' ? 'bg-slate-300' : 'bg-orange-400'}`}></div>
            
            <div className="flex flex-col items-center text-center">
              <div className="relative mb-4">
                <img src={customer.avatar} alt={customer.name} className="w-20 h-20 rounded-full border-4 border-slate-50 shadow-md" />
                <span className={`absolute bottom-0 right-0 px-2 py-0.5 rounded-lg text-[8px] font-black text-white ${customer.loyaltyLevel === 'طلایی' ? 'bg-amber-400' : 'bg-slate-500'}`}>
                  {customer.loyaltyLevel}
                </span>
              </div>
              <h3 className="text-lg font-black text-slate-800 mb-1">{customer.name}</h3>
              <p className="text-xs text-slate-400 font-bold mb-4" dir="ltr">{customer.phone}</p>

              <div className="grid grid-cols-2 w-full gap-4 border-t border-slate-50 pt-4">
                <div>
                  <p className="text-[10px] text-slate-400 font-bold uppercase">سفارشات</p>
                  <p className="text-sm font-black text-slate-800">{customer.totalOrders}</p>
                </div>
                <div>
                  <p className="text-[10px] text-slate-400 font-bold uppercase">مجموع خرید</p>
                  <p className="text-sm font-black text-orange-600">{customer.totalSpend.toLocaleString()}</p>
                </div>
              </div>

              <div className="mt-6 w-full space-y-2">
                <button className="w-full py-2.5 rounded-xl bg-orange-50 text-orange-600 text-xs font-black hover:bg-orange-500 hover:text-white transition-all">
                  مشاهده تاریخچه خرید
                </button>
                <button className="w-full py-2.5 rounded-xl border border-slate-100 text-slate-400 text-xs font-black hover:bg-slate-50 transition-all">
                  ارسال پیامک اختصاصی
                </button>
              </div>
            </div>
          </div>
        ))}
        
        {/* Add Customer Card */}
        <button className="bg-slate-50 rounded-[2.5rem] border-2 border-dashed border-slate-200 flex flex-col items-center justify-center p-6 hover:bg-white hover:border-orange-300 group transition-all">
          <div className="w-16 h-16 rounded-full bg-white flex items-center justify-center text-slate-300 group-hover:text-orange-500 transition-colors mb-4 border border-slate-100">
            <i className="fa-solid fa-plus text-2xl"></i>
          </div>
          <span className="text-sm font-black text-slate-400 group-hover:text-orange-600">افزودن مشتری جدید</span>
        </button>
      </div>
    </div>
  );
};

export default Customers;
