
import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { STATS, SALES_CHART_DATA, RECENT_ORDERS } from '../constants';
import { OrderStatus } from '../types';

const Dashboard: React.FC = () => {
  const getStatusColor = (status: OrderStatus) => {
    switch (status) {
      case OrderStatus.DELIVERED: return 'bg-emerald-100 text-emerald-700 border-emerald-200';
      case OrderStatus.SHIPPED: return 'bg-blue-100 text-blue-700 border-blue-200';
      case OrderStatus.COOKING: return 'bg-amber-100 text-amber-700 border-amber-200';
      case OrderStatus.CANCELLED: return 'bg-rose-100 text-rose-700 border-rose-200';
      default: return 'bg-slate-100 text-slate-700';
    }
  };

  return (
    <div className="p-6 space-y-8 max-w-7xl mx-auto">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {STATS.map((stat, idx) => (
          <div key={idx} className={`p-6 bg-white rounded-3xl border-2 border-slate-100 shadow-sm transition-transform hover:-translate-y-1`}>
            <div className="flex items-center justify-between mb-4">
              <div className={`p-3 rounded-2xl bg-${stat.color}-50 text-${stat.color}-600`}>
                <i className={`fa-solid ${stat.icon} text-xl`}></i>
              </div>
              <span className={`text-xs font-black px-2 py-1 rounded-lg ${stat.isPositive ? 'bg-emerald-50 text-emerald-600' : 'bg-rose-50 text-rose-600'}`}>
                {stat.change}
              </span>
            </div>
            <p className="text-slate-500 text-sm font-bold mb-1">{stat.label}</p>
            <p className="text-2xl font-black text-slate-800">{stat.value}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Sales Chart */}
        <div className="lg:col-span-2 bg-white p-6 rounded-3xl border-2 border-slate-100 shadow-sm">
          <div className="flex items-center justify-between mb-8">
            <h3 className="text-lg font-black text-slate-800">نمودار فروش هفتگی (کل شعب)</h3>
            <select className="bg-slate-50 border border-slate-200 rounded-xl px-4 py-2 text-sm font-bold">
              <option>۷ روز گذشته</option>
              <option>۳۰ روز گذشته</option>
            </select>
          </div>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={SALES_CHART_DATA}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 12, fontWeight: 'bold' }} dy={10} />
                <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12, fontWeight: 'bold' }} dx={-10} />
                <Tooltip 
                  contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)', padding: '12px' }}
                  itemStyle={{ color: '#f97316', fontWeight: 'bold' }}
                />
                <Bar dataKey="sales" radius={[8, 8, 0, 0]} barSize={40}>
                  {SALES_CHART_DATA.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={index === 6 ? '#f97316' : '#fdba74'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Branch Overview Quick List */}
        <div className="bg-white p-6 rounded-3xl border-2 border-slate-100 shadow-sm">
          <h3 className="text-lg font-black text-slate-800 mb-6">وضعیت لحظه‌ای شعب 📍</h3>
          <div className="space-y-4">
            {['آمل', 'بابل', 'بابلسر', 'ساری'].map((city, idx) => (
              <div key={idx} className="flex items-center justify-between p-4 rounded-2xl bg-slate-50 border border-slate-100 transition-hover hover:border-orange-200">
                <div className="flex items-center gap-3">
                  <span className="text-xl">🏙️</span>
                  <div>
                    <p className="text-sm font-black text-slate-800">{city}</p>
                    <p className="text-[10px] text-slate-500 font-bold">پیک فعال: {Math.floor(Math.random() * 10)}</p>
                  </div>
                </div>
                <div className={`px-3 py-1 rounded-full text-[10px] font-black ${idx === 2 ? 'bg-rose-100 text-rose-600' : 'bg-emerald-100 text-emerald-600'}`}>
                  {idx === 2 ? 'بسته' : 'باز'}
                </div>
              </div>
            ))}
          </div>
          <button className="w-full mt-6 py-3 rounded-2xl bg-orange-50 text-orange-600 font-black text-sm hover:bg-orange-100 transition-colors">
            مشاهده جزییات تمام شعب
          </button>
        </div>
      </div>

      {/* Recent Orders Table */}
      <div className="bg-white rounded-3xl border-2 border-slate-100 shadow-sm overflow-hidden">
        <div className="p-6 border-b border-slate-100 flex items-center justify-between">
          <h3 className="text-lg font-black text-slate-800">آخرین سفارشات ثبت شده 📝</h3>
          <button className="text-orange-500 font-bold text-sm">مشاهده همه</button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-right border-collapse">
            <thead>
              <tr className="bg-slate-50">
                <th className="px-6 py-4 text-xs font-black text-slate-500 uppercase tracking-wider">شناسه</th>
                <th className="px-6 py-4 text-xs font-black text-slate-500 uppercase tracking-wider">مشتری</th>
                <th className="px-6 py-4 text-xs font-black text-slate-500 uppercase tracking-wider">شعبه</th>
                <th className="px-6 py-4 text-xs font-black text-slate-500 uppercase tracking-wider">مبلغ کل</th>
                <th className="px-6 py-4 text-xs font-black text-slate-500 uppercase tracking-wider">زمان</th>
                <th className="px-6 py-4 text-xs font-black text-slate-500 uppercase tracking-wider">وضعیت</th>
                <th className="px-6 py-4 text-xs font-black text-slate-500 uppercase tracking-wider">عملیات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {RECENT_ORDERS.map((order) => (
                <tr key={order.id} className="hover:bg-slate-50 transition-colors">
                  <td className="px-6 py-4 text-sm font-black text-slate-800">{order.id}</td>
                  <td className="px-6 py-4 text-sm font-bold text-slate-700">{order.customerName}</td>
                  <td className="px-6 py-4 text-sm text-slate-600 font-bold">{order.branch}</td>
                  <td className="px-6 py-4 text-sm font-black text-slate-800">{order.totalPrice.toLocaleString()} تومان</td>
                  <td className="px-6 py-4 text-sm text-slate-500 font-bold">{order.date}</td>
                  <td className="px-6 py-4">
                    <span className={`px-3 py-1.5 rounded-xl text-[10px] font-black border ${getStatusColor(order.status)}`}>
                      {order.status}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <button className="p-2 text-slate-400 hover:text-orange-500 transition-colors">
                      <i className="fa-solid fa-eye"></i>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
