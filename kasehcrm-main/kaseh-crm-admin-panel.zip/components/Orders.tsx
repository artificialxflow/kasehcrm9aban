
import React, { useState } from 'react';
import { RECENT_ORDERS } from '../constants';
import { OrderStatus } from '../types';

const Orders: React.FC = () => {
  const [filter, setFilter] = useState<string>('همه');

  const getStatusColor = (status: OrderStatus) => {
    switch (status) {
      case OrderStatus.DELIVERED: return 'bg-emerald-100 text-emerald-700 border-emerald-200';
      case OrderStatus.SHIPPED: return 'bg-blue-100 text-blue-700 border-blue-200';
      case OrderStatus.COOKING: return 'bg-amber-100 text-amber-700 border-amber-200';
      case OrderStatus.CANCELLED: return 'bg-rose-100 text-rose-700 border-rose-200';
      default: return 'bg-slate-100 text-slate-700';
    }
  };

  const filteredOrders = filter === 'همه' 
    ? RECENT_ORDERS 
    : RECENT_ORDERS.filter(o => o.status === filter);

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-black text-slate-800">مدیریت سفارشات 📝</h2>
          <p className="text-slate-500 font-bold">نمایش و پیگیری تمامی سفارشات ثبت شده در لحظه</p>
        </div>
        <div className="flex gap-2 bg-white p-1.5 rounded-2xl border border-slate-200 shadow-sm overflow-x-auto whitespace-nowrap">
          {['همه', OrderStatus.COOKING, OrderStatus.SHIPPED, OrderStatus.DELIVERED, OrderStatus.CANCELLED].map((status) => (
            <button
              key={status}
              onClick={() => setFilter(status)}
              className={`px-4 py-2 rounded-xl text-xs font-black transition-all ${filter === status ? 'bg-orange-500 text-white' : 'text-slate-500 hover:bg-slate-50'}`}
            >
              {status}
            </button>
          ))}
        </div>
      </div>

      <div className="bg-white rounded-[2rem] border-2 border-slate-100 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-right border-collapse">
            <thead>
              <tr className="bg-slate-50/50">
                <th className="px-6 py-5 text-xs font-black text-slate-400">شناسه</th>
                <th className="px-6 py-5 text-xs font-black text-slate-400">مشتری</th>
                <th className="px-6 py-5 text-xs font-black text-slate-400">جزییات سفارش</th>
                <th className="px-6 py-5 text-xs font-black text-slate-400">شعبه</th>
                <th className="px-6 py-5 text-xs font-black text-slate-400">زمان</th>
                <th className="px-6 py-5 text-xs font-black text-slate-400">مبلغ نهایی</th>
                <th className="px-6 py-5 text-xs font-black text-slate-400">وضعیت</th>
                <th className="px-6 py-5 text-xs font-black text-slate-400">عملیات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredOrders.map((order) => (
                <tr key={order.id} className="hover:bg-slate-50/50 transition-colors group">
                  <td className="px-6 py-5 text-sm font-black text-slate-800">{order.id}</td>
                  <td className="px-6 py-5">
                    <div className="text-sm font-black text-slate-800">{order.customerName}</div>
                    <div className="text-[10px] text-slate-400 font-bold">کد عضویت: {Math.floor(Math.random()*9000)+1000}</div>
                  </td>
                  <td className="px-6 py-5">
                    <div className="flex flex-wrap gap-1">
                      {order.items.map((item, i) => (
                        <span key={i} className="px-2 py-0.5 bg-slate-100 text-slate-600 rounded-lg text-[10px] font-bold">
                          {item}
                        </span>
                      ))}
                    </div>
                  </td>
                  <td className="px-6 py-5 text-sm text-slate-600 font-bold">{order.branch}</td>
                  <td className="px-6 py-5 text-sm text-slate-500 font-bold">{order.date}</td>
                  <td className="px-6 py-5 text-sm font-black text-orange-600">{order.totalPrice.toLocaleString()} تومان</td>
                  <td className="px-6 py-5">
                    <span className={`px-4 py-1.5 rounded-xl text-[10px] font-black border ${getStatusColor(order.status)}`}>
                      {order.status}
                    </span>
                  </td>
                  <td className="px-6 py-5">
                    <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button className="w-8 h-8 rounded-lg bg-orange-50 text-orange-600 hover:bg-orange-500 hover:text-white transition-all">
                        <i className="fa-solid fa-print text-xs"></i>
                      </button>
                      <button className="w-8 h-8 rounded-lg bg-slate-100 text-slate-500 hover:bg-slate-800 hover:text-white transition-all">
                        <i className="fa-solid fa-ellipsis text-xs"></i>
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Orders;
