
import React from 'react';
import { Link, useLocation } from 'react-router-dom';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ isOpen, onClose }) => {
  const location = useLocation();

  const menuItems = [
    { name: 'داشبورد', path: '/', icon: 'fa-house' },
    { name: 'مدیریت شعب', path: '/branches', icon: 'fa-location-dot' },
    { name: 'سفارشات', path: '/orders', icon: 'fa-file-lines' },
    { name: 'مشتریان', path: '/customers', icon: 'fa-users' },
    { name: 'گزارشات', path: '/reports', icon: 'fa-chart-simple' },
  ];

  const activeClass = "bg-orange-500 text-white shadow-lg";
  const inactiveClass = "text-slate-600 hover:bg-orange-50 hover:text-orange-600";

  return (
    <>
      {/* Overlay for mobile */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 lg:hidden" 
          onClick={onClose}
        />
      )}
      
      <aside className={`
        fixed top-0 right-0 h-full w-64 bg-white border-l border-slate-200 z-50 transition-transform duration-300 ease-in-out lg:translate-x-0
        ${isOpen ? 'translate-x-0' : 'translate-x-full'}
      `}>
        <div className="p-6 flex items-center gap-3 border-b border-slate-100">
          <span className="text-3xl">🥣</span>
          <h1 className="text-2xl font-black text-orange-600 tracking-tight">کاسه</h1>
        </div>

        <nav className="mt-8 px-4 space-y-2">
          {menuItems.map((item) => {
            const isActive = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                onClick={() => { if (window.innerWidth < 1024) onClose(); }}
                className={`flex items-center gap-4 px-4 py-3 rounded-xl transition-all duration-200 font-bold ${isActive ? activeClass : inactiveClass}`}
              >
                <i className={`fa-solid ${item.icon} text-lg w-6`}></i>
                <span>{item.name}</span>
              </Link>
            );
          })}
        </nav>

        <div className="absolute bottom-8 left-4 right-4 p-4 bg-orange-50 rounded-2xl border border-orange-100">
          <p className="text-xs text-orange-800 font-bold mb-1">نسخه مدیریت ۱.۲</p>
          <p className="text-[10px] text-orange-600 leading-relaxed">بهینه‌سازی شده برای زنجیره شعب شمال ایران</p>
        </div>
      </aside>
    </>
  );
};

export default Sidebar;
