
import { OrderStatus, Order, Branch, Stat, Customer } from './types';

export const BRANCHES_DATA: Branch[] = [
  { id: '1', name: 'شعبه آمل', isOpen: true, activeCouriers: 5, city: 'آمل', dailyRevenue: 12500000 },
  { id: '2', name: 'شعبه بابل', isOpen: true, activeCouriers: 8, city: 'بابل', dailyRevenue: 18900000 },
  { id: '3', name: 'شعبه بابلسر', isOpen: false, activeCouriers: 0, city: 'بابلسر', dailyRevenue: 0 },
  { id: '4', name: 'شعبه ساری', isOpen: true, activeCouriers: 12, city: 'ساری', dailyRevenue: 24300000 },
];

export const RECENT_ORDERS: Order[] = [
  { id: '#1024', customerName: 'علی رضایی', branch: 'بابل', totalPrice: 450000, status: OrderStatus.DELIVERED, date: '۱۴:۳۰', items: ['کاسه کباب کوردی', 'دوغ محلی'] },
  { id: '#1025', customerName: 'مریم حسینی', branch: 'ساری', totalPrice: 890000, status: OrderStatus.SHIPPED, date: '۱۴:۴۵', items: ['جوجه کباب زعفرانی', 'ماست خیار'] },
  { id: '#1026', customerName: 'رضا مرادی', branch: 'آمل', totalPrice: 320000, status: OrderStatus.COOKING, date: '۱۵:۰۰', items: ['برنج کته', 'ماهی سفید'] },
  { id: '#1027', customerName: 'سارا امینی', branch: 'ساری', totalPrice: 1200000, status: OrderStatus.COOKING, date: '۱۵:۰۵', items: ['سینی مخصوص کاسه', 'زیتون پرورده'] },
  { id: '#1028', customerName: 'حسین جعفری', branch: 'بابل', totalPrice: 670000, status: OrderStatus.DELIVERED, date: '۱۵:۲۰', items: ['کباب کوبیده', 'شربت بهارنارنج'] },
  { id: '#1029', customerName: 'زهرا سلطانی', branch: 'آمل', totalPrice: 150000, status: OrderStatus.CANCELLED, date: '۱۵:۳۰', items: ['میرزا قاسمی'] },
];

export const STATS: Stat[] = [
  { label: 'فروش کل امروز', value: '۵۵,۷۰۰,۰۰۰ تومان', change: '+۱۲٪', isPositive: true, icon: 'fa-shopping-basket', color: 'orange' },
  { label: 'سفارشات در جریان', value: '۴۸', change: '+۵', isPositive: true, icon: 'fa-utensils', color: 'blue' },
  { label: 'مشتریان جدید', value: '۱۲۴', change: '+۱۸٪', isPositive: true, icon: 'fa-users', color: 'green' },
  { label: 'نرخ رضایت', value: '۹۴٪', change: '-۲٪', isPositive: false, icon: 'fa-smile', color: 'purple' },
];

export const SALES_CHART_DATA = [
  { name: 'شنبه', sales: 4000 },
  { name: 'یکشنبه', sales: 3000 },
  { name: 'دوشنبه', sales: 2000 },
  { name: 'سه‌شنبه', sales: 2780 },
  { name: 'چهارشنبه', sales: 1890 },
  { name: 'پنجشنبه', sales: 4390 },
  { name: 'جمعه', sales: 5490 },
];

export const CUSTOMERS_DATA: Customer[] = [
  { id: '1', name: 'علیرضا تهرانی', phone: '۰۹۱۲۳۴۵۶۷۸۹', totalOrders: 42, totalSpend: 8400000, lastOrder: '۱۴۰۳/۰۲/۱۵', avatar: 'https://i.pravatar.cc/150?u=1', loyaltyLevel: 'طلایی' },
  { id: '2', name: 'مهسا علیزاده', phone: '۰۹۱۱۱۱۱۱۱۱۱', totalOrders: 28, totalSpend: 5600000, lastOrder: '۱۴۰۳/۰۲/۲۰', avatar: 'https://i.pravatar.cc/150?u=2', loyaltyLevel: 'نقره‌ای' },
  { id: '3', name: 'کامران نجفی', phone: '۰۹۳۳۳۳۳۳۳۳۳', totalOrders: 15, totalSpend: 3100000, lastOrder: '۱۴۰۳/۰۲/۲۱', avatar: 'https://i.pravatar.cc/150?u=3', loyaltyLevel: 'برنزی' },
  { id: '4', name: 'نیلوفر باقری', phone: '۰۹۸۸۸۸۸۸۸۸۸', totalOrders: 35, totalSpend: 7200000, lastOrder: '۱۴۰۳/۰۲/۱۸', avatar: 'https://i.pravatar.cc/150?u=4', loyaltyLevel: 'طلایی' },
];

export const BRANCH_SHARE_DATA = [
  { name: 'ساری', value: 45 },
  { name: 'بابل', value: 30 },
  { name: 'آمل', value: 20 },
  { name: 'بابلسر', value: 5 },
];
